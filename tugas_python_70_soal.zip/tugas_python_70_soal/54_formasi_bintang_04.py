# Soal: Tampilkan formasi bintang 4
# Pola:
# *
# **
# ***
# ****
# *****
# ******
# *****
# ****
# ***
# **
# *
# Penjelasan: Belah ketupat vertikal sederhana (segitiga naik lalu turun)
# Asumsi: Pola diamond vertikal, karena sumber agak berantakan

# Bagian atas
for i in range(1, 7):
    print("*" * i)
# Bagian bawah
for i in range(5, 0, -1):
    print("*" * i)
