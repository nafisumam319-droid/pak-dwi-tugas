# Soal: Tampilkan formasi bintang 1
# Pola:
# ***********
# ***** *****
# ****  ****
# ***   ***
# **    **
# *     *
# Penjelasan: Baris pertama penuh 11 bintang, baris berikutnya bintang mengecil dengan spasi di tengah
# Asumsi: Mengikuti pola dari sumber, lebar 11, spasi tengah 1 lalu bertambah

# Baris pertama penuh
print("***********")
# Baris 2 sampai 6
for i in range(5, 0, -1):
    bintang = "*" * i
    spasi = " " * (6 - i)
    # Untuk i=5 spasi 1, i=4 spasi 2, dst agar terlihat melebar
    print(bintang + spasi + bintang)
