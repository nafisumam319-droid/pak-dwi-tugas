# Soal: Tampilkan formasi bintang 2
# Pola:
# *
# ***
# *****
# *******
# *********
# ***********
# Penjelasan: Segitiga dengan jumlah bintang ganjil bertambah
# Asumsi: 6 baris, tiap baris 2*n-1 bintang

for i in range(1, 7):
    jumlah = 2 * i - 1
    print("*" * jumlah)
