# Soal: Tampilkan formasi bintang 6
# Pola:
# *
# **
# ***
# ****
# *****
# ***********
# Penjelasan: Segitiga kecil lalu baris penuh di bawah
# Asumsi: Mengikuti potongan sumber: 5 baris segitiga lalu 11 bintang

for i in range(1, 6):
    print("*" * i)
print("***********")
