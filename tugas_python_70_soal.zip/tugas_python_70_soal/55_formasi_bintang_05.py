# Soal: Tampilkan formasi bintang 5
# Pola:
# ***********
# *********
# *******
# *****
# ***
# *
# Penjelasan: Segitiga terbalik dengan bintang ganjil
# Asumsi: Kebalikan dari formasi 2

for i in range(6, 0, -1):
    jumlah = 2 * i - 1
    print("*" * jumlah)
