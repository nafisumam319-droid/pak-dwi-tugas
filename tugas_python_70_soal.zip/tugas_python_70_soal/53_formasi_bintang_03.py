# Soal: Tampilkan formasi bintang 3
# Pola:
#     *
#    **
#   ***
#  ****
# *****
# ******
# Penjelasan: Segitiga siku rata kanan
# Asumsi: 6 baris, bintang bertambah, spasi berkurang

for i in range(1, 7):
    spasi = " " * (6 - i)
    bintang = "*" * i
    print(spasi + bintang)
